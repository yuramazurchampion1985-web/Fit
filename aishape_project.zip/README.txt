Інструкція по запуску:

1) Встановіть Python 3.8+.
2) Створіть віртуальне середовище:
   python3 -m venv venv
   source venv/bin/activate    (Linux/macOS)
   venv\Scripts\activate     (Windows)
3) Встановіть залежності:
   pip install -r requirements.txt
4) Скопіюйте в середовище змінні оточення:
   export TELEGRAM_BOT_TOKEN="токен_вашого_бота"
   export WAYFORPAY_SECRET_KEY="ваш_wayforpay_secret"
   export PDF_FONT_PATH="fonts/DejaVuSans.ttf"
   export PORT=5000
5) Запустіть додаток:
   python app.py
6) Налаштуйте WayForPay webhook на:
   https://<ваш_домен_або_ngrok>/wayforpay_webhook
7) Після успішної оплати бот надішле PDF-план в Telegram користувачу.

